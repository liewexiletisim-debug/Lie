
create table public.members (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null default auth.uid() references auth.users(id) on delete cascade,
  name       text not null check (char_length(btrim(name)) between 1 and 60),
  created_at timestamptz not null default now()
);

create table public.records (
  id         uuid primary key default gen_random_uuid(),
  member_id  uuid not null references public.members(id) on delete cascade,
  user_id    uuid not null default auth.uid() references auth.users(id) on delete cascade,
  type       text not null check (type in ('not','hafif','orta','agir','kick','ban')),
  reason     text not null check (char_length(btrim(reason)) between 1 and 2000),
  created_at timestamptz not null default now()
);

create index members_user_idx on public.members(user_id);
create index records_member_idx on public.records(member_id);
create index records_user_idx on public.records(user_id);

alter table public.members enable row level security;
alter table public.records enable row level security;

grant select, insert, update, delete on public.members, public.records to authenticated;

-- Herkes sadece kendi kayıtlarını görür/değiştirir.
create policy "members_owner" on public.members
  for all to authenticated
  using (user_id = (select auth.uid()))
  with check (user_id = (select auth.uid()));

create policy "records_owner" on public.records
  for all to authenticated
  using (user_id = (select auth.uid()))
  with check (
    user_id = (select auth.uid())
    and member_id in (select id from public.members where user_id = (select auth.uid()))
  );
